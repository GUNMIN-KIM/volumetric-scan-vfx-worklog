import sys,pathlib,subprocess
sys.path.insert(0,'work/python');import cv2,numpy as np,imageio_ffmpeg
r=pathlib.Path('outputs/scan-vfx/Assets');caps={n:cv2.VideoCapture(str(r/(n+'.mp4'))) for n in ['Normal','Alpha','Specular']};yy,xx=np.mgrid[:540,:960];names=['floor','wall-left','wall-right','ceiling','window-reflection','table','chairs','microphones','fragments','person-left','person-right']
def wr(n):return subprocess.Popen([imageio_ffmpeg.get_ffmpeg_exe(),'-y','-threads','1','-f','rawvideo','-pix_fmt','gray','-s','960x540','-r','24','-i','-','-an','-c:v','libx264','-threads','1','-preset','ultrafast','-crf','16',str(r/(n+'-matte.mp4'))],stdin=subprocess.PIPE,stderr=subprocess.DEVNULL)
ws={n:wr(n) for n in names}
for k in range(480):
 fs={n:cv2.resize(c.read()[1],(960,540)) for n,c in caps.items()};norm=fs['Normal'].astype(float);a=fs['Alpha'][:,:,0]>12;guard=cv2.dilate(a.astype('uint8'),np.ones((17,17),np.uint8))>0;void=np.max(np.abs(norm-[255,127,128]),axis=2)<7;obj=~void&~guard
 nc,lab,stats,cent=cv2.connectedComponentsWithStats((~void).astype('uint8'),8);small=[i for i in range(1,nc) if 3<stats[i,4]<550];fragments=np.isin(lab,small)&obj
 floor=(norm[:,:,1]>170)&(norm[:,:,1]>norm[:,:,2]+12)&obj
 table=floor&(yy>170)&(yy<325);floor &= ~table
 ceiling=obj&(yy<125)&(norm[:,:,1]<110)
 window=obj&(cv2.cvtColor(fs['Specular'],cv2.COLOR_BGR2GRAY)>170)&(yy<320)&~ceiling
 microphones=np.zeros((540,960),bool)
 for x0,x1 in [(120,480),(480,850)]:
  pts=np.argwhere(a&(xx>x0)&(xx<x1)&(yy<270))
  if len(pts):
   top=pts[:,0].min();head=pts[pts[:,0]<top+45];hx=np.median(head[:,1]);microphones|=(np.abs(xx-(hx+22))<17)&(yy<top+50)&obj
 chairs=obj&(yy>290)&(yy<485)&(xx>220)&(xx<780)&~floor&~table
 used=fragments|floor|table|ceiling|window|microphones|chairs;wall=obj&~used
 masks={'floor':floor,'table':table,'ceiling':ceiling,'window-reflection':window,'microphones':microphones,'chairs':chairs,'fragments':fragments,'wall-left':wall&(xx<480),'wall-right':wall&(xx>=480),'person-left':a&(xx<480),'person-right':a&(xx>=480)}
 for n,mask in masks.items():
  m=mask.astype('uint8')*255;m=cv2.GaussianBlur(m,(3,3),.65);ws[n].stdin.write(m.tobytes())
 if k%120==0:print('objects',k,flush=True)
for w in ws.values():w.stdin.close();w.wait()
