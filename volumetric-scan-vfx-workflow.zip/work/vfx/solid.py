import sys,subprocess,pathlib
sys.path.insert(0,'work/python');import cv2,numpy as np,imageio_ffmpeg
r=pathlib.Path('outputs/scan-vfx/Assets');src=cv2.VideoCapture(str(r/'source.mp4'));alpha=cv2.VideoCapture(str(r/'Alpha.mp4'));ff=imageio_ffmpeg.get_ffmpeg_exe();p=subprocess.Popen([ff,'-y','-f','rawvideo','-pix_fmt','bgr24','-s','1920x1080','-r','24','-i','-','-an','-c:v','libx264','-crf','16','-preset','fast','-pix_fmt','yuv420p',str(r/'background-cleanplate-solid.mp4')],stdin=subprocess.PIPE,stderr=subprocess.DEVNULL)
ap=subprocess.Popen([ff,'-y','-f','rawvideo','-pix_fmt','gray','-s','1920x1080','-r','24','-i','-','-an','-c:v','libx264','-crf','12',str(r/'person-solid-alpha.mp4')],stdin=subprocess.PIPE,stderr=subprocess.DEVNULL)
for n in range(480):
 ok,f=src.read();ok2,a=alpha.read()
 if not(ok and ok2):break
 m=cv2.cvtColor(a,cv2.COLOR_BGR2GRAY);mask=(cv2.resize(m,(480,270))>12).astype(np.uint8)*255;mask=cv2.dilate(mask,np.ones((3,3),np.uint8));small=cv2.resize(f,(480,270));fill=cv2.inpaint(small,mask,5,cv2.INPAINT_TELEA);fill=cv2.resize(fill,(1920,1080));full=(m>12).astype(np.uint8);f[full>0]=fill[full>0];p.stdin.write(f.tobytes());ap.stdin.write((full*255).tobytes())
 if n%96==0:print('cleanplate',n,flush=True)
p.stdin.close();ap.stdin.close();p.wait();ap.wait();print('done',flush=True)
