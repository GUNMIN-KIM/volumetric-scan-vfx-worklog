import sys
sys.path.insert(0,'work/python');import cv2,numpy as np
for nm in ['FINAL_SCAN_VFX_1','FINAL_SCAN_VFX_20s']:
 c=cv2.VideoCapture('/Users/withnoshore/Downloads/'+nm+'.mp4');print(nm,c.get(3),c.get(4),c.get(5),c.get(7));fs=[]
 for t in [1,5,9,13,17]:
  c.set(cv2.CAP_PROP_POS_MSEC,t*1000);ok,f=c.read()
  if ok:fs.append(cv2.resize(f,(576,324)))
 cv2.imwrite('work/vfx/'+nm+'-sheet.jpg',np.vstack(fs))
