import sys,subprocess,pathlib
sys.path.insert(0,'work/python');import cv2,numpy as np,imageio_ffmpeg
r=pathlib.Path('outputs/scan-vfx/Assets');c=cv2.VideoCapture(str(r/'Alpha.mp4'));p=subprocess.Popen([imageio_ffmpeg.get_ffmpeg_exe(),'-y','-f','rawvideo','-pix_fmt','gray','-s','960x540','-r','24','-i','-','-an','-c:v','libx264','-crf','15','-pix_fmt','yuv420p',str(r/'person-guard.mp4')],stdin=subprocess.PIPE,stderr=subprocess.DEVNULL)
for n in range(480):
 ok,a=c.read()
 if not ok:break
 m=cv2.cvtColor(cv2.resize(a,(960,540)),cv2.COLOR_BGR2GRAY);m=cv2.dilate(m,np.ones((61,61),np.uint8));m=cv2.GaussianBlur(m,(31,31),10);p.stdin.write(m.tobytes())
p.stdin.close();p.wait()
