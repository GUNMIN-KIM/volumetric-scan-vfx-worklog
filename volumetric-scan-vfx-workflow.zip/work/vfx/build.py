import json,pathlib
root=pathlib.Path('outputs/scan-vfx').resolve();data=json.loads((root/'Assets/tracks.json').read_text())
js=r'''(function(){
app.beginUndoGroup('SCAN VFX EDIT');
var ROOT=__ROOT__,D=__DATA__;var report=[];
function log(s){report.push(s);var f=new File(ROOT+'/build-report.txt');f.open('w');f.write(report.join('\n'));f.close();}
try{
var folder=app.project.items.addFolder('SCAN VFX - editable');
var src=app.project.importFile(new ImportOptions(new File(ROOT+'/Assets/source.mp4')));src.parentFolder=folder;
function comp(n){var c=app.project.items.addComp(n,1920,1080,1,20,24);c.parentFolder=folder;return c;}
function effect(l,n){return l.property('ADBE Effect Parade').addProperty(n);}
function ellipse(cx,cy,rx,ry){var s=new Shape();s.vertices=[[cx,cy-ry],[cx+rx,cy],[cx,cy+ry],[cx-rx,cy]];s.inTangents=[[-rx*.552,0],[0,-ry*.552],[rx*.552,0],[0,ry*.552]];s.outTangents=[[rx*.552,0],[0,ry*.552],[-rx*.552,0],[0,-ry*.552]];s.closed=true;return s;}
function protect(l){var m=l.Masks.addProperty('ADBE Mask Atom');m.name='Feathered performance protection';m.property('ADBE Mask Shape').setValue(ellipse(1010,390,440,380));m.property('ADBE Mask Feather').setValue([145,145]);return m;}
var scene=comp('01_SCAN_SPACE');
var bg=scene.layers.add(src);bg.name='BACKGROUND - continuous mesh drift';bg.audioEnabled=false;
var td=effect(bg,'ADBE Turbulent Displace');td.property(2).expression='20+9*Math.sin(time*2.1)+5*Math.sin(time*5.2)';td.property(3).setValue(165);td.property(5).setValue(1.65);td.property(6).expression='time*115';td.property(4).expression='[960+90*Math.sin(time*.53),540+65*Math.cos(time*.71)]';
var fg=scene.layers.add(src);fg.name='PERFORMANCE - protected lips and faces';fg.audioEnabled=true;protect(fg);
// All overlay coordinates are derived from image optical flow, not a solved 3D camera.
var overlay=comp('02_OPTICAL_FLOW_TRACKING');
var colors=[[.78,.96,.23],[.18,.9,.82],[1,.32,.48]];var kept=[];
function shapePath(layer,verts,closed,col,width){var g=layer.property('ADBE Root Vectors Group').addProperty('ADBE Vector Group');var contents=g.property('ADBE Vectors Group');var p=contents.addProperty('ADBE Vector Shape - Group');var s=new Shape();s.vertices=verts;s.closed=closed;p.property('ADBE Vector Shape').setValue(s);var st=contents.addProperty('ADBE Vector Graphic - Stroke');st.property('ADBE Vector Stroke Color').setValue(col);st.property('ADBE Vector Stroke Width').setValue(width);return contents.property(1).property('ADBE Vector Shape');}
for(var i=0;i<D.tracks.length;i++){
 var h=D.tracks[i];if(i%3==2)continue;
 var l=overlay.layers.addShape();l.name='TRACK_'+('000'+i).slice(-3);l.inPoint=h[0][0];l.outPoint=Math.min(20,h[h.length-1][0]+.04);l.property('ADBE Transform Group').property('ADBE Anchor Point').setValue([0,0]);
 var col=colors[i%11==0?2:(i%4==0?1:0)],size=i%5==0?20:8;
 shapePath(l,[[-size,-size],[size,-size],[size,size],[-size,size]],true,col,1.15);
 shapePath(l,[[-4,0],[4,0]],false,col,1);shapePath(l,[[0,-4],[0,4]],false,col,1);
 var ts=[],vs=[];for(var k=0;k<h.length;k++){ts.push(h[k][0]);vs.push([h[k][1],h[k][2]]);}l.property('ADBE Transform Group').property('ADBE Position').setValuesAtTimes(ts,vs);
 l.property('ADBE Transform Group').property('ADBE Opacity').expression='Math.min(1,(time-inPoint)/.12,(outPoint-time)/.12)*72';kept.push(l);
 if(i%6==0){var tx=overlay.layers.addText('P'+('000'+i).slice(-3));tx.name='Label '+i;tx.inPoint=l.inPoint;tx.outPoint=l.outPoint;var doc=tx.property('Source Text').value;doc.fontSize=13;doc.fillColor=col;doc.font='Menlo-Regular';tx.property('Source Text').setValue(doc);tx.parent=l;tx.property('Position').setValue([13,-13]);tx.property('Opacity').setValue(75);}
}
for(var j=1;j<kept.length;j+=3){var a=kept[j-1],b=kept[j];var inn=Math.max(a.inPoint,b.inPoint),out=Math.min(a.outPoint,b.outPoint);if(out-inn<.4)continue;var line=overlay.layers.addShape();line.name='Tracked connection '+j;line.inPoint=inn;line.outPoint=out;line.property('Position').setValue([0,0]);var path=shapePath(line,[[0,0],[1,1]],false,[.6,.85,.64],.65);path.expression='var a=thisComp.layer("'+a.name+'").transform.position;var b=thisComp.layer("'+b.name+'").transform.position;createPath([a,b],[],[],false)';line.property('Opacity').setValue(35);}
var ol=scene.layers.add(overlay);ol.name='Tracked surface markers';
// A second, soft peripheral surface adds depth separation without disturbing mouth timing.
var edge=scene.layers.add(src);edge.name='NEAR PLANE - peripheral parallax';edge.audioEnabled=false;var em=protect(edge);em.inverted=true;edge.property('Position').expression='[960+5*Math.sin(time*.9),540+3*Math.cos(time*.7)]';edge.property('Opacity').setValue(22);var ed=effect(edge,'ADBE Turbulent Displace');ed.property(2).setValue(32);ed.property(3).setValue(210);ed.property(6).expression='time*94';edge.moveAfter(ol);
log('Scene and '+kept.length+' optical-flow marker layers built');
var master=comp('FINAL_SCAN_VFX_20s');var base=master.layers.add(scene);base.name='SCAN SPACE / parallax composite';base.threeDLayer=true;
var cam=master.layers.addCamera('CAMERA - subtle 2.5D drift',[960,540]);cam.autoOrient=AutoOrientType.NO_AUTO_ORIENT;cam.property('Position').expression='[960+17*Math.sin(time*.52),540+9*Math.sin(time*.73),-2666+30*Math.sin(time*.41)]';cam.property('ADBE Camera Options Group').property('ADBE Camera Zoom').setValue(2666);base.property('Scale').setValue([104,104,104]);
var cuts=[3.375,5.625,7.583333,9.375,12.25,16];
// Native adjustment layers form short directional displacement transitions.
for(var q=0;q<cuts.length;q++){var t=cuts[q];var adj=master.layers.addSolid([1,1,1],'TRANSITION '+(q+1)+' - mesh displacement',1920,1080,1,20);adj.adjustmentLayer=true;adj.inPoint=t-.125;adj.outPoint=t+.208333;var de=effect(adj,'ADBE Turbulent Displace');de.property(2).setValuesAtTimes([t-.125,t,t+.208333],[0,60,0]);de.property(3).setValue(48);de.property(6).expression='time*550';var blur=effect(adj,'ADBE Gaussian Blur 2');blur.property(1).setValuesAtTimes([t-.125,t,t+.208333],[0,14,0]);var ex=effect(adj,'ADBE Exposure2');ex.property(3).setValuesAtTimes([t-.125,t,t+.208333],[0,.35,0]);master.markerProperty.setValueAtTime(t,new MarkerValue('Source scene change / mesh bridge'));}
var grade=master.layers.addSolid([1,1,1],'GRADE - contrast / cool shadows / warm lights',1920,1080,1,20);grade.adjustmentLayer=true;
var bc=effect(grade,'ADBE Brightness & Contrast 2');bc.property(1).setValue(-3);bc.property(2).setValue(24);
var vib=effect(grade,'ADBE Vibrance');vib.property(1).setValue(17);vib.property(2).setValue(-5);
var tint=effect(grade,'ADBE Tint');tint.property(1).setValue([.025,.065,.075]);tint.property(2).setValue([1,.91,.77]);tint.property(3).setValue(11);
var grain=effect(grade,'ADBE Noise');grain.property(1).setValue(2.4);grain.property(2).setValue(0);
master.motionBlur=true;master.shutterAngle=150;base.motionBlur=true;
master.openInViewer();master.time=4.5;
app.project.save(new File(ROOT+'/Scan_HipHop_VFX.aep'));
master.saveFrameToPng(4.5,new File(ROOT+'/preview.png'));
var rq=app.project.renderQueue.items.add(master);var om=rq.outputModule(1);log('OUTPUT TEMPLATES: '+om.templates.join(' | '));
try{om.applyTemplate('Apple ProRes 422');}catch(e){report.push('Default output module used');}
om.file=new File(ROOT+'/Scan_HipHop_VFX.mov');
app.project.save(new File(ROOT+'/Scan_HipHop_VFX.aep'));log('BUILD COMPLETE; project saved; render queued');
}catch(e){log('ERROR line '+e.line+': '+e.toString());}finally{app.endUndoGroup();}
})();'''
js=js.replace('__ROOT__',json.dumps(str(root))).replace('__DATA__',json.dumps(data))
pathlib.Path('work/vfx/build.jsx').write_text(js)
