import sys
sys.path.insert(0,'work/python');import cv2
c=cv2.VideoCapture('outputs/scan-vfx/Assets/source.mp4');c.set(cv2.CAP_PROP_POS_FRAMES,420);_,f=c.read();cv2.imwrite('work/vfx/source420.jpg',f)
