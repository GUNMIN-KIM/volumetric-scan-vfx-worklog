import sys
sys.path.insert(0,'work/pose-python');import mediapipe as mp,cv2
from mediapipe.tasks.python import vision
opts=vision.PoseLandmarkerOptions(base_options=mp.tasks.BaseOptions(model_asset_path='work/vfx/pose_landmarker.task'),num_poses=2,output_segmentation_masks=True)
with vision.PoseLandmarker.create_from_options(opts) as model:
 c=cv2.VideoCapture('/Users/withnoshore/Downloads/FINAL_SCAN_VFX_1.mp4');c.set(cv2.CAP_PROP_POS_MSEC,5000);_,f=c.read();f=cv2.resize(f,(960,540));res=model.detect(mp.Image(image_format=mp.ImageFormat.SRGB,data=cv2.cvtColor(f,cv2.COLOR_BGR2RGB)));print('poses',len(res.pose_landmarks));print([(p[0].x,p[0].y,p[15].visibility,p[16].visibility) for p in res.pose_landmarks])
