import sys,pathlib,json
sys.path.insert(0,'work/python');import cv2,numpy as np
names=['Depth','Metallic','Specular','Roughness','Normal','Alpha','BaseColor'];tiles=[];meta=[]
for n in names:
 p=pathlib.Path('/Users/withnoshore/Downloads')/(n+' (1).mp4');c=cv2.VideoCapture(str(p));fps=c.get(cv2.CAP_PROP_FPS);ct=c.get(cv2.CAP_PROP_FRAME_COUNT);c.set(cv2.CAP_PROP_POS_MSEC,4500);ok,f=c.read();meta.append({'name':n,'fps':fps,'frames':ct,'duration':ct/fps,'size':[c.get(3),c.get(4)]})
 if ok:
  f=cv2.resize(f,(480,270));cv2.putText(f,n,(14,28),cv2.FONT_HERSHEY_SIMPLEX,.7,(255,255,255),2);tiles.append(f)
print(json.dumps(meta,indent=2));pathlib.Path('work/vfx/passes.json').write_text(json.dumps(meta));tiles.append(np.zeros_like(tiles[0]));cv2.imwrite('work/vfx/passes.jpg',np.vstack([np.hstack(tiles[:4]),np.hstack(tiles[4:])]))
