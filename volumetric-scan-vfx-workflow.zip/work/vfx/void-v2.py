import sys,subprocess,pathlib
sys.path.insert(0,'work/python');import cv2,numpy as np,imageio_ffmpeg
r=pathlib.Path('outputs/scan-vfx/Assets');c=cv2.VideoCapture(str(r/'BaseColor.mp4'));a=cv2.VideoCapture(str(r/'Alpha.mp4'))
def writer(name,pix):return subprocess.Popen([imageio_ffmpeg.get_ffmpeg_exe(),'-y','-f','rawvideo','-pix_fmt',pix,'-s','960x540','-r','24','-i','-','-an','-c:v','libx264','-crf','16','-pix_fmt','yuv420p',str(r/name)],stdin=subprocess.PIPE,stderr=subprocess.DEVNULL)
normal=cv2.VideoCapture(str(r/'Normal.mp4'))
p=writer('void-matte-v2.mp4','gray');g=writer('void-glitch-v2.mp4','bgr24');yy,xx=np.mgrid[:540,:960]
for n in range(480):
 ok,f=c.read();ok2,al=a.read();ok3,norm=normal.read();norm=cv2.resize(norm,(960,540))
 if not ok:break
 f=cv2.resize(f,(960,540));al=cv2.resize(al,(960,540));hsv=cv2.cvtColor(f,cv2.COLOR_BGR2HSV);gray=cv2.cvtColor(f,cv2.COLOR_BGR2GRAY)
 local=cv2.absdiff(gray,cv2.GaussianBlur(gray,(7,7),0));candidate=((np.max(np.abs(norm.astype('float32')-np.array([255,127,128])),axis=2)<5)&(hsv[:,:,1]<40)&(local<7)).astype('uint8')
 count,labels,stats,cent=cv2.connectedComponentsWithStats(candidate,8);border=np.unique(np.concatenate([labels[0],labels[-1],labels[:,0],labels[:,-1]]));valid=[i for i in border if i and stats[i,4]>400];mask=np.isin(labels,valid).astype('uint8')*255
 mask=cv2.dilate(mask,np.ones((3,3),np.uint8));mask[al[:,:,0]>30]=0;mask=cv2.GaussianBlur(mask,(3,3),.6)
 t=n/24;rng=np.random.default_rng(n//3);v=87+6*np.sin(xx*.004+t*.55)+4*np.sin(yy*.011-t*.8);im=np.stack([v+5,v+3,v],2)
 for j in range(12):
  y=int(rng.integers(0,535));x=int(rng.integers(0,850));w=int(rng.integers(25,280));h=int(rng.choice([1,2,3,8,18]));im[y:y+h,x:x+w]+=rng.choice([-30,-18,18,30])
 im+=((yy+n*2)%9==0)[:,:,None]*-4
 for j in range(5):
  x=int((j*213+t*(8+j*5))%960);y=int((j*117+40*np.sin(t+j))%540);cv2.rectangle(im,(x,y),(x+35+j*8,y+12),(120,150,139),1)
 im=np.uint8(np.clip(im,0,255));p.stdin.write(mask.tobytes());g.stdin.write(im.tobytes())
 if n in [108,204]:cv2.imwrite(str(r.parent/('void-mask-%s.jpg'%n)),np.hstack([f,cv2.cvtColor(mask,cv2.COLOR_GRAY2BGR),im]))
p.stdin.close();g.stdin.close();p.wait();g.wait()
