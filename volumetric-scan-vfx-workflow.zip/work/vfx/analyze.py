import sys,pathlib,json,shutil
sys.path.insert(0,'work/python')
import cv2,numpy as np
root=pathlib.Path('outputs/scan-vfx');src=next(pathlib.Path('/Users/withnoshore/Downloads').glob('*1 - *mp4'));shutil.copy2(src,root/'Assets/source.mp4')
c=cv2.VideoCapture(str(src)); fps=c.get(cv2.CAP_PROP_FPS);frames=[]
while True:
 ok,f=c.read()
 if not ok:break
 frames.append(cv2.cvtColor(cv2.resize(f,(960,540)),cv2.COLOR_BGR2GRAY))
diffs=[float(np.mean(cv2.absdiff(frames[i],frames[i-1]))) for i in range(1,len(frames))]
peaks=sorted(range(len(diffs)),key=lambda i:diffs[i],reverse=True);sel=[]
for i in peaks:
 if all(abs(i-x)>18 for x in sel):sel.append(i)
 if len(sel)==12:break
print('fps',fps,'frames',len(frames),'changes',[(round((i+1)/fps,3),round(diffs[i],1)) for i in sorted(sel)])
# Track real image corners in short-lived batches; reject inconsistent tracks.
tracks=[]
for start in range(0,len(frames)-12,30):
 mask=np.zeros_like(frames[0]);mask[30:510,35:925]=255
 # Keep graphical markers away from the central face region.
 mask[55:245,300:710]=0
 pts=cv2.goodFeaturesToTrack(frames[start],maxCorners=20,qualityLevel=.025,minDistance=85,mask=mask)
 if pts is None:continue
 histories=[[[start/fps,float(p[0][0]*2),float(p[0][1]*2)]] for p in pts];active=np.ones(len(pts),bool)
 for t in range(start+1,min(start+55,len(frames))):
  nxt,st,err=cv2.calcOpticalFlowPyrLK(frames[t-1],frames[t],pts,None,winSize=(25,25),maxLevel=3)
  back,st2,e=cv2.calcOpticalFlowPyrLK(frames[t],frames[t-1],nxt,None,winSize=(25,25),maxLevel=3)
  good=(st[:,0]>0)&(st2[:,0]>0)&(np.linalg.norm(back[:,0]-pts[:,0],axis=1)<1.3)&(err[:,0]<22)&(np.linalg.norm(nxt[:,0]-pts[:,0],axis=1)<32)
  active &=good
  for k in range(len(pts)):
   if active[k] and t%2==0: histories[k].append([t/fps,float(nxt[k,0,0]*2),float(nxt[k,0,1]*2)])
  pts=nxt
 for h in histories:
  if len(h)>=9:tracks.append(h)
(root/'Assets/tracks.json').write_text(json.dumps({'fps':fps,'duration':min(20,len(frames)/fps),'tracks':tracks,'changes':[(i+1)/fps for i in sorted(sel)]}))
print('valid tracks',len(tracks))
