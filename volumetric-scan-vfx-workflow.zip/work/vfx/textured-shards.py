import sys,pathlib,subprocess
sys.path.insert(0,'work/python');import cv2,numpy as np,imageio_ffmpeg
from scipy.spatial import Delaunay
r=pathlib.Path('outputs/scan-vfx/Assets');c=cv2.VideoCapture(str(r/'source.mp4'));c.set(cv2.CAP_PROP_POS_MSEC,7200);_,f=c.read();gray=cv2.cvtColor(f,cv2.COLOR_BGR2GRAY);edges=cv2.Canny(gray,65,150);pts=cv2.goodFeaturesToTrack(gray,650,.025,20).reshape(-1,2);tri=Delaunay(pts).simplices
outs=[]
for name in ['shard-textured-wire.mp4','shard-textured-dots.mp4']:
 outs.append(subprocess.Popen([imageio_ffmpeg.get_ffmpeg_exe(),'-y','-f','rawvideo','-pix_fmt','bgr24','-s','1920x1080','-r','24','-i','-','-an','-c:v','libx264','-threads','2','-preset','fast','-crf','15',str(r/name)],stdin=subprocess.PIPE,stderr=subprocess.DEVNULL))
yy,xx=np.mgrid[:1080,:1920]
for n in range(24):
 t=n/24*2*np.pi;out=f.copy();patch=(np.sin(xx*.017+yy*.006+t)+np.cos(yy*.023-t*.4)>1.3);lines=np.zeros_like(f)
 for tr in tri:
  p=pts[tr];cx,cy=np.int32(p.mean(0));length=np.linalg.norm(p-np.roll(p,1,axis=0),axis=1).max()
  if length<100 and patch[cy,cx]:cv2.polylines(lines,[p.astype('int32')],True,(145,177,164),1,cv2.LINE_AA)
 active=lines.max(2)>0;out[active]=(.5*out[active]+.5*lines[active]).astype('uint8')
 for j,p in enumerate(pts):
  x,y=np.int32(p)
  if j%17==0 and patch[y,x]:cv2.drawMarker(out,(x,y),(152,186,170),cv2.MARKER_CROSS,4,1)
 dots=f.copy();mask=patch&(edges>0);dots[mask]=(dots[mask]*.4).astype('uint8');ys,xs=np.where(mask&((xx%3)==0)&((yy%3)==0));dots[ys,xs]=np.minimum(255,f[ys,xs].astype(int)+70).astype('uint8')
 for j in range(0,len(xs),80):
  x,y=xs[j],ys[j];dx=int(4*np.sin(t+y*.02));cv2.circle(dots,(int(x+dx),int(y)),1,(150,177,164),-1)
 outs[0].stdin.write(out.tobytes());outs[1].stdin.write(dots.tobytes())
for p in outs:p.stdin.close();p.wait()
print('READY')
