import Foundation
import AVFoundation
import Vision
import CoreImage
let input=CommandLine.arguments[1], output=CommandLine.arguments[2]
let asset=AVURLAsset(url:URL(fileURLWithPath:input))
let track=asset.tracks(withMediaType:.video)[0]
let reader=try AVAssetReader(asset:asset)
let ro=AVAssetReaderTrackOutput(track:track,outputSettings:[kCVPixelBufferPixelFormatTypeKey as String:kCVPixelFormatType_32BGRA]);reader.add(ro)
try? FileManager.default.removeItem(atPath:output)
let writer=try AVAssetWriter(outputURL:URL(fileURLWithPath:output),fileType:.mov)
let wi=AVAssetWriterInput(mediaType:.video,outputSettings:[AVVideoCodecKey:AVVideoCodecType.h264,AVVideoWidthKey:960,AVVideoHeightKey:540,AVVideoCompressionPropertiesKey:[AVVideoAverageBitRateKey:6000000]])
let adapter=AVAssetWriterInputPixelBufferAdaptor(assetWriterInput:wi,sourcePixelBufferAttributes:[kCVPixelBufferPixelFormatTypeKey as String:kCVPixelFormatType_32BGRA,kCVPixelBufferWidthKey as String:960,kCVPixelBufferHeightKey as String:540,kCVPixelBufferIOSurfacePropertiesKey as String:[:]])
writer.add(wi);writer.startWriting();writer.startSession(atSourceTime:.zero);reader.startReading()
let req=VNGeneratePersonSegmentationRequest();req.qualityLevel = .accurate;req.outputPixelFormat=kCVPixelFormatType_OneComponent8
let handler=VNSequenceRequestHandler();let ctx=CIContext(options:[.cacheIntermediates:false]);var n=0
while let sample=ro.copyNextSampleBuffer(){
 if n>=480 {break}
 autoreleasepool {
 guard let px=CMSampleBufferGetImageBuffer(sample) else{return}
 do {try handler.perform([req],on:px)} catch {print(error)}
 if let mask=req.results?.first?.pixelBuffer {
 let im=CIImage(cvPixelBuffer:mask);let resized=im.transformed(by:CGAffineTransform(scaleX:960/im.extent.width,y:540/im.extent.height))
 var dest:CVPixelBuffer?;CVPixelBufferPoolCreatePixelBuffer(nil,adapter.pixelBufferPool!,&dest)
 ctx.render(resized,to:dest!)
 while !wi.isReadyForMoreMediaData {Thread.sleep(forTimeInterval:0.01)}
 adapter.append(dest!,withPresentationTime:CMTime(value:Int64(n),timescale:24))
 }
 }
 n+=1;if n%48==0{print("matte \(n)/480");fflush(stdout)}
}
wi.markAsFinished();let sem=DispatchSemaphore(value:0);writer.finishWriting{sem.signal()};sem.wait();print("done \(n) status \(writer.status.rawValue)")
