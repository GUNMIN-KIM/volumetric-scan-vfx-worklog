import sys,pathlib,subprocess
sys.path.insert(0,'work/python');import cv2,numpy as np,imageio_ffmpeg
from scipy.spatial import Delaunay
r=pathlib.Path('outputs/scan-vfx/Assets');c=cv2.VideoCapture(str(r/'source.mp4'));c.set(cv2.CAP_PROP_POS_MSEC,7200);_,frame=c.read();d=cv2.VideoCapture(str(r/'Depth.mp4'));d.set(cv2.CAP_PROP_POS_MSEC,7200);_,depth=d.read();depth=cv2.cvtColor(depth,cv2.COLOR_BGR2GRAY)/255.;gray=cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)
def writer(name):return subprocess.Popen([imageio_ffmpeg.get_ffmpeg_exe(),'-y','-f','rawvideo','-pix_fmt','bgr24','-s','1920x1080','-r','24','-i','-','-an','-c:v','libx264','-threads','2','-preset','fast','-crf','15',str(r/name)],stdin=subprocess.PIPE,stderr=subprocess.DEVNULL)
a=writer('shard-wire-pointer.mp4');b=writer('shard-fine-points.mp4');rng=np.random.default_rng(45);yy,xx=np.mgrid[8:1080:20,8:1920:20];pts=np.column_stack([xx.ravel(),yy.ravel()]).astype(float);pts+=rng.uniform(-5,5,pts.shape);tri=Delaunay(pts).simplices;py,px=np.mgrid[2:1078:3,2:1918:3];px=px.ravel();py=py.ravel();brightness=gray[py,px]/255.;colors=np.column_stack([brightness*150+50,brightness*155+65,brightness*145+50]).astype('uint8');z=depth[py,px]
# One second cyclic asset; AE loops it while each foreground layer sweeps across screen.
for n in range(24):
 t=n/24*2*np.pi;wire=np.uint8(frame*.08);m=pts.copy();m[:,0]+=7*np.sin(t+pts[:,1]*.008)*depth[np.clip(pts[:,1].astype(int),0,1079),np.clip(pts[:,0].astype(int),0,1919)];m[:,1]+=3*np.cos(t+pts[:,0]*.009);polys=np.int32(m[tri]);cv2.polylines(wire,list(polys),True,(67,100,92),1,cv2.LINE_AA)
 for j in range(0,len(m),29):
  x,y=np.int32(m[j]);cv2.drawMarker(wire,(x,y),(155,197,173),cv2.MARKER_CROSS,5,1)
 for j in range(0,len(m),370):
  x,y=np.int32(m[j]);cv2.polylines(wire,[np.array([[x,y],[x+1,y+14],[x+5,y+9],[x+11,y+9]],np.int32)],True,(173,203,186),1,cv2.LINE_AA)
 points=np.zeros_like(frame);points[:]=(5,8,7);qx=np.clip((px+8*np.sin(t+py*.006)*z).astype(int),0,1919);qy=np.clip((py+3*np.cos(t+px*.006)*z).astype(int),0,1079);points[qy,qx]=colors
 a.stdin.write(wire.tobytes());b.stdin.write(points.tobytes())
a.stdin.close();b.stdin.close();a.wait();b.wait();print('READY')
