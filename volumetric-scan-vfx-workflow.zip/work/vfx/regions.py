import sys,pathlib,subprocess
sys.path.insert(0,'work/python');import cv2,numpy as np,imageio_ffmpeg
r=pathlib.Path('outputs/scan-vfx/Assets');caps={n:cv2.VideoCapture(str(r/(n+'.mp4'))) for n in ['Normal','Alpha','Specular','Metallic']}
def wr(n):return subprocess.Popen([imageio_ffmpeg.get_ffmpeg_exe(),'-y','-f','rawvideo','-pix_fmt','gray','-s','960x540','-r','24','-i','-','-an','-c:v','libx264','-crf','15',str(r/(n+'-region.mp4'))],stdin=subprocess.PIPE,stderr=subprocess.DEVNULL)
ws={n:wr(n) for n in ['floor','wall','reflective']}
for k in range(480):
 fs={n:cv2.resize(c.read()[1],(960,540)) for n,c in caps.items()};norm=fs['Normal'].astype(float);a=cv2.dilate(fs['Alpha'][:,:,0],np.ones((25,25),np.uint8))>25;void=np.max(np.abs(norm-[255,127,128]),axis=2)<8
 floor=(norm[:,:,1]>175)&(norm[:,:,1]>norm[:,:,2]+15);wall=(norm[:,:,2]>155)&~floor;spec=cv2.cvtColor(fs['Specular'],cv2.COLOR_BGR2GRAY);metal=cv2.cvtColor(fs['Metallic'],cv2.COLOR_BGR2GRAY);refl=(spec>155)&(metal>15)&~floor
 for n,mask in [('floor',floor),('wall',wall),('reflective',refl)]:
  mask=(mask&~a&~void).astype('uint8')*255;mask=cv2.GaussianBlur(mask,(9,9),2);ws[n].stdin.write(mask.tobytes())
for w in ws.values():w.stdin.close();w.wait()
