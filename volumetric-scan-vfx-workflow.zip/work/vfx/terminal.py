import sys,subprocess,pathlib
sys.path.insert(0,'work/python');import cv2,numpy as np,imageio_ffmpeg
r=pathlib.Path('outputs/scan-vfx/Assets');p=subprocess.Popen([imageio_ffmpeg.get_ffmpeg_exe(),'-y','-f','rawvideo','-pix_fmt','bgr24','-s','960x540','-r','24','-i','-','-an','-c:v','libx264','-crf','16','-pix_fmt','yuv420p',str(r/'void-terminal.mp4')],stdin=subprocess.PIPE,stderr=subprocess.DEVNULL)
logs=['> scan_cache / recover','ERR 0x0A : missing surface','reproject / frame buffer','mesh chunk unavailable','retrying depth alignment...','> tracking correspondence lost','offset: +0.004 / -0.021','restoring texture blocks','partial reconstruction [ ]','cache read fault / 0x000F','> recover --continue']
for n in range(480):
 rng=np.random.default_rng(n//4);im=np.full((540,960,3),(17,19,18),dtype=np.uint8);t=n/24
 for j in range(19):
  y=24+j*27-int(t*9)%27;idx=(j+int(t*9)//27)%len(logs);x=18 if j%6 else 560;col=(77,98,86) if j%5 else (113,127,116)
  txt=logs[idx] if j%3 else ('%08X  '%(j*9823+n//12)+'00 7F 00 FF 8A .. ??')
  if rng.random()<.12:txt=txt[:int(rng.integers(5,len(txt)))]+ '_ #  []'
  cv2.putText(im,txt,(x,y),cv2.FONT_HERSHEY_PLAIN,.78,col,1,cv2.LINE_AA)
 if n%47<5:
  for j in range(3):
   y=int(rng.integers(0,520));im[y:y+12]=np.roll(im[y:y+12],int(rng.integers(-60,60)),axis=1)
 if n%24<12:cv2.rectangle(im,(18,515),(24,523),(112,135,118),-1)
 im[::3]=(im[::3].astype(float)*.85).astype('uint8');p.stdin.write(im.tobytes())
p.stdin.close();p.wait()
