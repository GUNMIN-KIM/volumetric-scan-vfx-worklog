import sys,subprocess,pathlib
sys.path.insert(0,'work/python');import cv2,numpy as np,imageio_ffmpeg
r=pathlib.Path('outputs/scan-vfx/Assets');c=cv2.VideoCapture(str(r/'source.mp4'));f=imageio_ffmpeg.get_ffmpeg_exe()
p=subprocess.Popen([f,'-y','-f','rawvideo','-pix_fmt','rgb24','-s','960x540','-r','24','-i','-','-an','-c:v','libx264','-crf','17','-pix_fmt','yuv420p',str(r/'surface-points.mp4')],stdin=subprocess.PIPE,stderr=subprocess.DEVNULL)
y,x=np.mgrid[:540,:960];grid=((x%4==0)&(y%4==0));n=0
while n<480:
 ok,a=c.read()
 if not ok:break
 a=cv2.resize(a,(960,540));g=cv2.cvtColor(a,cv2.COLOR_BGR2GRAY);edges=cv2.Canny(g,55,120);v=cv2.dilate(edges,np.ones((3,3),np.uint8))/255
 out=np.zeros((540,960,3),np.uint8);sel=grid&(v>.2);out[sel]=[168,239,99]
 p.stdin.write(out.tobytes());n+=1
p.stdin.close();p.wait();print('surface point pass',n)
