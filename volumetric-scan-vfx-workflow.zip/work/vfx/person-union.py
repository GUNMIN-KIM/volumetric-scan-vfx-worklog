import sys,pathlib,subprocess
sys.path.insert(0,'work/python');import cv2,numpy as np,imageio_ffmpeg
r=pathlib.Path('outputs/parts-composite/Assets');names=[s+'-'+p for s in ['left','right'] for p in ['head','face','hand-L','hand-R','body']];cs=[cv2.VideoCapture(str(r/(n+'.mp4'))) for n in names];p=subprocess.Popen([imageio_ffmpeg.get_ffmpeg_exe(),'-y','-f','rawvideo','-pix_fmt','gray','-s','960x540','-r','24','-i','-','-an','-c:v','libx264','-threads','2','-preset','fast','-crf','14',str(r/'person-background-guard.mp4')],stdin=subprocess.PIPE,stderr=subprocess.DEVNULL)
for k in range(480):
 m=np.zeros((540,960),np.uint8)
 for c in cs:
  ok,f=c.read()
  if ok:m=cv2.max(m,cv2.cvtColor(f,cv2.COLOR_BGR2GRAY))
 m=cv2.dilate(m,np.ones((65,65),np.uint8));m=cv2.GaussianBlur(m,(45,45),12);p.stdin.write(m.tobytes())
p.stdin.close();p.wait()
