import sys,pathlib,subprocess,json
sys.path.insert(0,'work/pose-stable');import cv2,numpy as np,mediapipe as mp
sys.path.insert(0,'work/python');import imageio_ffmpeg
from mediapipe.tasks.python import vision
cv2.setNumThreads(2);r=pathlib.Path('outputs/parts-composite');r.mkdir(exist_ok=True);assets=r/'Assets';assets.mkdir(exist_ok=True)
opts=vision.PoseLandmarkerOptions(base_options=mp.tasks.BaseOptions(model_asset_path='work/vfx/pose_landmarker.task'),num_poses=1,min_pose_detection_confidence=.15,min_pose_presence_confidence=.15,output_segmentation_masks=True)
model=vision.PoseLandmarker.create_from_options(opts);caps=[cv2.VideoCapture('/Users/withnoshore/Downloads/'+n+'.mp4') for n in ['FINAL_SCAN_VFX_1','FINAL_SCAN_VFX_20s']];names=[s+'-'+p for s in ['left','right'] for p in ['head','face','hand-L','hand-R','body']]+['table-edges','window-details']
def wr(name,size,pix='gray'):
 return subprocess.Popen([imageio_ffmpeg.get_ffmpeg_exe(),'-y','-f','rawvideo','-pix_fmt',pix,'-s',size,'-r','24','-i','-','-an','-c:v','libx264','-threads','1','-preset','ultrafast','-crf','16','-pix_fmt','yuv420p',str(assets/(name+'.mp4'))],stdin=subprocess.PIPE,stderr=subprocess.DEVNULL)
ws={n:wr(n,'960x540') for n in names};out=wr('aligned-detail-source','3840x2160','bgr24');dis=cv2.DISOpticalFlow_create(cv2.DISOPTICAL_FLOW_PRESET_MEDIUM);gy,gx=np.mgrid[:2160,:3840].astype('float32');sy,sx=np.mgrid[:540,:960].astype('float32');last={};stats={s:0 for s in ['left','right']}
for n in range(480):
 frames=[c.read()[1] for c in caps];base,detail=[cv2.resize(f,(960,540)) for f in frames];bgray=cv2.cvtColor(base,cv2.COLOR_BGR2GRAY);dgray=cv2.cvtColor(detail,cv2.COLOR_BGR2GRAY);flow=dis.calc(bgray,dgray,None);flow=cv2.GaussianBlur(flow,(9,9),2);big=cv2.resize(flow,(3840,2160))*4;aligned=cv2.remap(frames[1],gx+big[:,:,0],gy+big[:,:,1],cv2.INTER_LINEAR,borderMode=cv2.BORDER_REFLECT);out.stdin.write(aligned.tobytes());masks={};people=np.zeros((540,960),np.uint8)
 for side,x0,x1 in [('left',0,535),('right',425,960)]:
  crop=base[:,x0:x1];res=model.detect(mp.Image(image_format=mp.ImageFormat.SRGB,data=np.ascontiguousarray(cv2.cvtColor(crop,cv2.COLOR_BGR2RGB))))
  if res.pose_landmarks:
   stats[side]+=1;pts=np.array([[p.x*(x1-x0)+x0,p.y*540] for p in res.pose_landmarks[0]]);seg=np.zeros((540,960),np.uint8);sm=res.segmentation_masks[0].numpy_view();seg[:,x0:x1]=(cv2.resize(sm,(x1-x0,540))>.4).astype('uint8')*255
   parts={};nose=pts[0];earspan=max(12,np.linalg.norm(pts[7]-pts[8]));shoulder=max(45,np.linalg.norm(pts[11]-pts[12]));rad=max(earspan*.7,shoulder*.18);head=np.zeros_like(seg);cv2.ellipse(head,tuple(np.int32(nose+[0,-rad*.2])),(int(rad*1.2),int(rad*1.5)),0,0,360,255,-1);head=cv2.bitwise_and(head,seg);face=np.zeros_like(seg);cv2.ellipse(face,tuple(np.int32(nose+[0,rad*.18])),(int(rad*.77),int(rad*.88)),0,0,360,255,-1);face=cv2.bitwise_and(face,seg);parts['face']=face;parts['head']=cv2.subtract(head,face);used=cv2.max(head,face)
   for label,ids in [('hand-L',[15,17,19,21]),('hand-R',[16,18,20,22])]:
    h=np.zeros_like(seg);hp=pts[ids];cv2.fillConvexPoly(h,cv2.convexHull(np.int32(hp)),255);h=cv2.dilate(h,np.ones((13,13),np.uint8));h=cv2.bitwise_and(h,seg);parts[label]=h;used=cv2.max(used,h)
   parts['body']=cv2.subtract(seg,used);last[side]=parts
  parts=last.get(side,{p:np.zeros((540,960),np.uint8) for p in ['head','face','hand-L','hand-R','body']})
  for p,m in parts.items():masks[side+'-'+p]=m;people=cv2.max(people,m)
 edges=cv2.Canny(bgray,60,150);protect=cv2.dilate(people,np.ones((19,19),np.uint8));edges[protect>0]=0
 table=np.zeros_like(edges);lines=cv2.HoughLinesP(edges,1,np.pi/180,50,minLineLength=65,maxLineGap=18)
 if lines is not None:
  for ln in lines[:,0]:
   x1,y1,x2,y2=ln
   if 185<(y1+y2)/2<355 and abs(y2-y1)<.22*abs(x2-x1):cv2.line(table,(x1,y1),(x2,y2),255,8)
 window=cv2.dilate(edges,np.ones((3,3),np.uint8));window[(sy>285)|(sx>390)|(sx<90)]=0;window[protect>0]=0;window[(bgray<105)]=0
 masks['table-edges']=table;masks['window-details']=window
 for name in names:ws[name].stdin.write(cv2.GaussianBlur(masks[name],(3,3),.55).tobytes())
 if n in [24,120,216,312,408]:
  check=base.copy();mask=np.zeros((540,960,3),np.uint8)
  for j,name in enumerate(names):mask[masks[name]>127]=[(j*67)%255,(j*103)%255,180]
  cv2.imwrite(str(r/('masks-%03d.jpg'%n)),np.hstack([base,mask]))
 if n%48==0:print('frame',n,'detections',stats,flush=True)
for p in list(ws.values())+[out]:p.stdin.close();p.wait()
model.close();(r/'tracking-report.json').write_text(json.dumps(stats));print('READY',flush=True)
