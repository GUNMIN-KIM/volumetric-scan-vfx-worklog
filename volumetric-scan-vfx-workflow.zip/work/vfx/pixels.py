import sys
sys.path.insert(0,'work/python');import cv2
for name in ['BaseColor','Normal']:
 c=cv2.VideoCapture('outputs/scan-vfx/Assets/'+name+'.mp4');c.set(cv2.CAP_PROP_POS_FRAMES,204);_,f=c.read();print(name,[f[y,x].tolist() for x,y in [(20,20),(1850,500),(50,700)]]);print('hsv',[cv2.cvtColor(f,cv2.COLOR_BGR2HSV)[y,x].tolist() for x,y in [(20,20),(1850,500),(50,700)]])
