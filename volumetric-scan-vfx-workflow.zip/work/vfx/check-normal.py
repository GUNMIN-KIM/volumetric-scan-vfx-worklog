import sys
sys.path.insert(0,'work/python');import cv2
c=cv2.VideoCapture('outputs/scan-vfx/Assets/Normal.mp4')
for n in [0,108,204,420]:
 c.set(0 if False else cv2.CAP_PROP_POS_FRAMES,n);ok,f=c.read();cv2.imwrite('work/vfx/normal-%s.jpg'%n,cv2.resize(f,(960,540)));print(n,f[20,20],f[900,1700])
