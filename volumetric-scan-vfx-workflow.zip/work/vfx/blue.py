import sys,subprocess
sys.path.insert(0,'work/python');import imageio_ffmpeg
r='outputs/scan-vfx/Assets/'
subprocess.run([imageio_ffmpeg.get_ffmpeg_exe(),'-y','-i',r+'void-glitch.mp4','-vf','lutrgb=r=val*0.15:g=val*0.40:b=val*1.6+45','-an','-c:v','libx264','-crf','16',r+'void-y2k-blue.mp4'],stderr=subprocess.DEVNULL,check=True)
