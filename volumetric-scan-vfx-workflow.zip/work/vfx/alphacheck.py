import sys
sys.path.insert(0,'work/python');import cv2,numpy as np
cs=[cv2.VideoCapture('outputs/scan-vfx/Assets/'+x+'.mp4') for x in ['source','Alpha','background-cleanplate-tight']];fs=[]
for c in cs:c.set(cv2.CAP_PROP_POS_FRAMES,420);_,f=c.read();fs.append(f)
cv2.imwrite('work/vfx/alpha420.jpg',np.hstack([cv2.resize(f,(640,360)) for f in fs]))
